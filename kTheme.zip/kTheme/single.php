<?php get_header(); ?>


	<h1> Single few</h1>
	<div class="container">

       <div class="image-fluid"> <?php the_post_thumbnail(array(600,600)); ?>
       </div>
         <br>
       <?php if(have_posts()) : ?> <!--  If there are posts available  -->

       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop
-->
       <a href="<?php the_permalink(); ?>"><!--retrieves URL for the permalink-->
          <?php the_title(); ?>    <!--retrieves blog title-->
       </a>

       <p><?php the_time('M j, Y G:i'); ?></p><!--retrieves date blog entry was created-->

       <p> <?php the_author(); ?></p><!--retrieves author of blog entry-->
       
       <?php the_content(); ?><!--retrieves content-->

         <div><?php comments_template(); ?> </div>

       <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>  <!-- no posts found displayed -->
       <?php endif; ?> <!-- end if -->
   </div>

<?php get_footer(); ?>