<?php get_header(); ?>


	
	<div class="container">

       <?php if(have_posts()) : ?> <!--  If there are posts available  -->

       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop
-->

    <h1 class="text-danger"><?php the_title(); ?> </h1>   <!--retrieves blog title-->
       

       <?php the_content(); ?><!--retrieves content-->

       <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>  <!-- no posts found displayed -->
       <?php endif; ?> <!-- end if -->
   </div>

<?php get_footer(); ?>