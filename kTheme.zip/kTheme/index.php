<?php get_header(); ?>

<div class="container">

    <div class="card bg-dark text-white border-0">
        <img src="<?php echo get_template_directory_uri(); ?>/img/elephant.jpg" class="card-img" alt="...">
        <div class="card-img-overlay">
            <h1 class="card-title text-white">Static Content Blog</h1>
            <p class="card-text">Your favorite WP theme!</p>

        </div>
    </div>

    <!-- <img class="img-responsive" src="<?php //echo get_template_directory_uri(); ?>/img/elephant.jpg" alt="image" style="width: 80vw;"> -->

    <p>static content static content static content static content static content static content static content static
        content static content static content static content static content static content static content static content
        static content static content static content static content </p>

    <!-- <?php //require_once 'slider.php' ?> -->

    <div class="container">
        <div class="row">

            <?php if(have_posts()) : ?>
            <!--  If there are posts available  -->

            <?php while(have_posts()) : the_post(); ?>
            <!-- if there are posts, iterate the posts in the loop
-->

            <div class="card border-0 col-sm-12 col-md-6 col-lg-4">
                <?php $image =  wp_get_attachment_image_src(get_post_thumbnail_id($post->ID ), 'full'); ?>
                <img src="<?php echo $image[0];?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php the_title(); ?></h5>
                    <p> <?php the_author(); ?></p>
                    <p><?php the_time('M j, Y G:i'); ?></p>
                    <p class="card-text"><?php the_excerpt(); ?></p>
                    <a href="<?php the_permalink(); ?>" class="btn btn-info">Go somewhere</a>
                </div>
            </div>


            <?php endwhile; ?>
            <!--end the while loop-->

            <?php else :?>
            <!-- if no posts are found then: -->

            <p>No posts found</p> <!-- no posts found displayed -->
            <?php endif; ?>
            <!-- end if -->
            
            <div class="col-4">
            <?php get_sidebar(); ?>
            </div>


        </div>
    
    </div>


</div>

<?php get_footer(); ?>