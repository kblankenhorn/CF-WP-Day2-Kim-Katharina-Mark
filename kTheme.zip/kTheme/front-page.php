<?php get_header(); ?>



<div class="container">
    <div class="row">
    
    <div class="card bg-dark text-white border-0">
  <img src="<?php echo get_template_directory_uri(); ?>/img/elephant.jpg" class="card-img" alt="...">
  <div class="card-img-overlay">
    <h1 class="card-title text-white">Static Content Blog</h1>
    <p class="card-text">Your favorite WP theme!</p>

  </div>
</div>
    
    
    
    </div>

</div>











<?php get_footer(); ?>